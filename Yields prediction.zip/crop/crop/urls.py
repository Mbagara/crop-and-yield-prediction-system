from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('analyze', views.analyze, name='analyze'),
    path('about_us/', views.about_us,name='about_us')
]